package com.example.project.basic_api.data.model

data class LamaranModel(
    var uid: String ="",
    var id: String ="",
    val name: String="",
    val tempatlahir: String="",
    var tgllahir: String="",
    val jk: String="",
    var status: String="",
    val surat: String="",
    val cv: String=""
)
