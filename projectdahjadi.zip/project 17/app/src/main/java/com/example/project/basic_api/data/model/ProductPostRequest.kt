package com.example.project.basic_api.data.model

data class ProductPostRequest(
    val name: String,
    val description: String,
    val price: Int
)
