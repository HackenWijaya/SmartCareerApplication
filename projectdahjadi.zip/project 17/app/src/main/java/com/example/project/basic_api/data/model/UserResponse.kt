package com.example.project.basic_api.data.model

data class UserResponse(
    val id: String?,
    val name: String,
    val username: String,
    val email: String
)