package com.example.project.basic_api.ui.view.main.home

data class NewsHorizontalModel(
    val newsTitle: String,
    val imageUrl: String
)
