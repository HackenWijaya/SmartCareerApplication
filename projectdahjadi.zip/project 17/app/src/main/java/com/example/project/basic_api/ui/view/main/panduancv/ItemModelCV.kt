package com.example.project.basic_api.ui.view.main.panduancv
data class ItemModelCV(
    val name: String,
    val desc:String

)



