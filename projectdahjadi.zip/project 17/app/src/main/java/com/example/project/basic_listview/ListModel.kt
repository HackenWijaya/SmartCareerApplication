package com.example.project.basic_listview

data class ListModel(
    val name: String,
    val desc:String,
    val imageResId: Int
)
