package com.example.project.basic_recycleview

import android.media.Image

data class ItemModel(
    val imageUrl: String,
    val description: String
)
